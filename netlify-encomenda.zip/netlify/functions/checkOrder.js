exports.handler = async function(event, context) {
  try {
    const body = JSON.parse(event.body);

    const response = await fetch("https://futtransfer.top/api/checkOrder", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        apiUser: body.apiUser,
        apiKey: body.apiKey,
        orderID: body.orderID
      })
    });

    const data = await response.json();

    return {
      statusCode: 200,
      body: JSON.stringify(data)
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
};
